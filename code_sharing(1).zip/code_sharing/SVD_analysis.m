function [R,t] = SVD_analysis(P1,p,t_couple)
    [~,size_p]=size(p);
    for i=1:size_p
        P2(:,i)=(p(:,i)+t_couple)/norm(p(:,i)+t_couple);
    end
    
    av_P1=mean(P1,2);
    av_P2=mean(P2,2);
    
    H=zeros(3);
    for i=1:size_p
        H=H+( P2(:,i)-av_P2  )*(    P1(:,i)-av_P1    )';
    end
    
    [U,S,V]=svd(H);
    R=V*U';
    t=R*t_couple;
%     if sign(det(R))==1
%         t=R*t_couple;
%         if t(3)<0
%             R=-[V(:,1:2) -V(:,3)]*U';
%             t=R*t_couple;
%         end
%     else
%         R=[V(:,1:2) -V(:,3)]*U';
%         t=R*t_couple;
%         if t(3)<0
%             R =- V*(U');
%             t=R*t_couple;
%         end
%     end
    if sign(det(R))==-1
        R=[V(:,1:2) -V(:,3)]*U';
        t=R*t_couple;
    end
    
end

