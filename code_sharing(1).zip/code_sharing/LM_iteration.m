function [x_final,error_final,error_iteration_save] = LM_iteration(x_initial,p,d)
%�ο�����   https://blog.csdn.net/lingyunxianhe/article/details/80469984
%%
e1=10^-12;      e2=10^-12;   tau=10^-10;
k=1;  v=2;   x=x_initial;
%%
J = Jacobi(x,p,d);    fx= Get_fx(x,d,p);    A=J'*J;     g=J'*fx;  error_iteration_save(k)=0.5*fx'*fx;
found=(norm(g,inf)<e1);
mu=tau*max([A(1,1),A(2,2),A(3,3)]);
while (~found && k<1000)
    k=k+1;    h_lm=-1*inv(A+mu*eye(3))*g;
    if norm(h_lm)<e2*(norm(x)+e2)
        found=true;
    else
        x_new=x+h_lm;
        fx= Get_fx(x,d,p);Fx=0.5*fx'*fx;      fx_h= Get_fx(x_new,d,p);Fx_h=0.5*fx_h'*fx_h;  error_iteration_save(k)=Fx;
        l_0=fx; L_0=0.5*l_0'*l_0;             l_h=fx+J*h_lm;L_h=0.5*l_h'*l_h;
        rho=(Fx-Fx_h)/(L_0-L_h);
        if rho>0
            x=x_new;
            J = Jacobi(x,p,d);    fx= Get_fx(x,d,p);    A=J'*J;     g=J'*fx;
            found=(norm(g)<=e1);
            mu=mu*max([0.3333,1-(2*rho-1).^3]);
            v=2;
        else
            mu=mu*v;  v=2*v;
        end
    end
end
x_final=x; error_final=0.5*fx'*fx;
x_final(3)=abs(x_final(3));
end

