function [fx] = Get_fx(t,d,p)
[~,size_p]=size(p);
size_error=0;
for i=1:size_p-1
    for j=i+1:size_p
        %% ����������ͶӰ��������
        P_i=p(:,i)+t;
        P_si=P_i/norm(P_i);
        P_j=p(:,j)+t;
        P_sj=P_j/norm(P_j);
        %%
        size_error=size_error+1;
        fx(size_error,1)=2-2*P_si'*P_sj-d(size_error);
    end
end

end

