function [A] = Jacobi(t,p,l)
[~,size_p]=size(p);
size_A=0;
for i=1:size_p-1
    for j=i+1:size_p
        %% ����������ͶӰ��������
        P_i=p(:,i)+t;
        P_si=P_i/norm(P_i);
        P_j=p(:,j)+t;
        P_sj=P_j/norm(P_j);
        %%
        J=-2*(       (1/norm(P_j)-P_si'*P_sj/norm(P_i))*P_si'  +        (1/norm(P_i)-P_si'*P_sj/norm(P_j))*P_sj'          );
        size_A=size_A+1;
        A(size_A,:)=J;
    end
end
end

